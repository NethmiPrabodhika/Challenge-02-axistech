import React from 'react'
import "../Layout/Header.css"

function Header() {
  return (
    <div class="container "style={{marginBottom:'500px'}}>

    <div class="rectangle"></div>
    </div>
  )
}

export default Header