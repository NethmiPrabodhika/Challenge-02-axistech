import React , {useState , useEffect} from "react";
import SiteRoutes from "./Router";

function App() {
  return (
    <div>
      <SiteRoutes/>
    </div>
  );
}

export default App;
