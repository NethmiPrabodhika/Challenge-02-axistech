import React, { useState, useEffect } from "react";
import ReactDOM from "react-dom";
import {
    CardWrapper,
    CardHeader,
    CardHeading,
    CardBody,
    CardIcon,
    CardFieldset,
    CardInput,
    CardOptionsItem,
    CardOptions,
    CardOptionsNote,
    CardButton,
    CardLink,

} from "./Card";
import { Getfundraising } from "../Services/DonateService";
import { CardImg } from "reactstrap";
import "../style.css";



function ViewFunds() {

    const [Dataset, setDataset] = useState([]);

    const getAllData = async () => {
        try {
            const response = await Getfundraising();
            setDataset(response?.data?.data);
        } catch (error) {
            console.log(error);
        }
    }

    useEffect(() => {
        getAllData();
    }, [])

    return (
        <div>
          
            <div className="card" style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between' }}>
                {Dataset.map((item, index) => {
                    return (
                        <div class="card" style={{
                            backgroundColor:"#FFFFFF",
                            display: 'flex',
                            borderRadius:"10px",
                            flexDirection: "column",
                            alignItems: "flex-start",
                            padding: "25px",
                            gap: "17px",
                            position: "17px",
                            width: "386px",
                            height: "548px",
                            left: "922px",
                            top: "696px",
                            


                        }}>
                            <CardWrapper>
                                <CardHeader>
                                    <CardHeading>{item.title}</CardHeading>
                                </CardHeader>

                                <CardBody >

                                    <CardFieldset>

                                        <CardImg
                                            width="100%"
                                            height="100%"
                                            src={item.urls.small}
                                            alt="User Img"

                                        />
                                        <CardFieldset>
                                            <CardOptionsNote><b>{item.title}</b></CardOptionsNote>
                                            <CardOptionsNote><b>{item.target_amount}</b></CardOptionsNote>
                                        </CardFieldset>

                                    </CardFieldset>

                                    <CardFieldset>
                                        <CardButton type="button">Donate Now</CardButton>
                                    </CardFieldset>

                                </CardBody>
                            </CardWrapper>
                        </div>
                    )
                })}

            </div>
        </div>
    );
}

export default ViewFunds;
